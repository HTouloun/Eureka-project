package org.ENSAJ.ServiceVoiture.Service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.ENSAJ.ServiceVoiture.Model.Client;

@FeignClient(name="service-client")
public interface ClientService {
    @GetMapping("/client/{id}")
    Client clientById(@PathVariable Long id);
}