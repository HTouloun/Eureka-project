package org.ENSAJ.ServiceVoiture;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoitureApplicationTests {

	@Test
	void contextLoads() {
	}

}
